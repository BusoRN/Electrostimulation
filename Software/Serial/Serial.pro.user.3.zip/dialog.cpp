/****************************************************************************
**
**
**
****************************************************************************/

#include "dialog.h"

#include <QLabel>
#include <QLineEdit>
#include <QComboBox>
#include <QSpinBox>
#include <QPushButton>
#include <QGridLayout>
#include <QDebug>
#include <QList>
#include <QString>

#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>

QT_USE_NAMESPACE

int start = 0;
QSerialPort *serial; //constructor of my pserial port
QGridLayout *mainLayout = new QGridLayout;
QSerialPortInfo QSPInfo[8];
bool status = false;
QByteArray buso;
char buffer[4];

char widthChar[3];

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , transactionCount(0)
    , serialPortLabel(new QLabel(tr("Serial port:")))
    , serialPortComboBox(new QComboBox())
    , widthLabel(new QLabel(tr("Select the width for pulse [ms]:")))
    , widthSpinBox(new QSpinBox())
    //, requestLabel(new QLabel(tr("Request:")))
    //, requestLineEdit(new QLineEdit(tr("Who are you?")))
    , trafficLabel(new QLabel(tr("No traffic.")))
    , statusLabel(new QLabel(tr("Status: Not running.")))
    , runButton(new QPushButton(tr("Start")))
    // openButton(new QPushButton(tr("Open")))
    , updateButton(new QPushButton(tr("Update Ports")))

{
    //this->setWindowTitle("Buso");
    int i= 0;

        foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
        {
            int x = QString::compare(info.manufacturer(), "Texas Instruments", Qt::CaseInsensitive);
            int y = QString::compare(info.manufacturer(), "TI", Qt::CaseInsensitive);
            if((x&y) == 0)
            {
                serialPortComboBox->addItem(info.description()+" - "+info.portName());
                QSPInfo[i] = info;
                i++;
            }
        }

    widthSpinBox->setRange(1, 500);
    widthSpinBox->setValue(1);


    mainLayout->addWidget(serialPortLabel, 0, 0);
    mainLayout->addWidget(serialPortComboBox, 0, 1);
    mainLayout->addWidget(widthLabel, 1,0);
    mainLayout->addWidget(widthSpinBox, 1,1 );
    mainLayout->addWidget(runButton, 4, 1);
    //mainLayout->addWidget(openButton, 4,0);
    mainLayout->addWidget(updateButton, 4,0);
    mainLayout->addWidget(trafficLabel, 2, 0, 1, 4);
    mainLayout->addWidget(statusLabel, 3, 0, 1, 5);
    setLayout(mainLayout);

    serial = new QSerialPort(this);

    setWindowTitle(tr("Blocking Master"));
    serialPortComboBox->setFocus();


    connect(runButton, SIGNAL(clicked()),
            this, SLOT(transaction()));

   // connect(openButton, SIGNAL(clicked()),
     //       this, SLOT(openSerial()));

    connect(updateButton, SIGNAL(clicked()),
            this, SLOT(updatePorts()));
}

void Dialog::transaction()
{
    bool status = false;

    int index = serialPortComboBox->currentIndex();
    trafficLabel->setText(QSPInfo[index].portName());

    serial->setPortName(QSPInfo[index].portName());//

    status = serial->open(QIODevice::ReadWrite);

    if(status)
    {
        serial->setBaudRate(QSerialPort::Baud9600,QSerialPort::AllDirections); // to set the wished Baudrate
        serial->setDataBits(QSerialPort::Data8);//to set the word length
        serial->setParity(QSerialPort::NoParity);
        serial->setStopBits(QSerialPort::OneStop);
        serial->setFlowControl(QSerialPort::NoFlowControl);
    }

    itoa(widthSpinBox->value(),buffer,10);

    statusLabel->setText(buffer);

    serial->write(buffer);
    serial->putChar('\r');
    statusLabel->setText("Redy to go!");
    //serial->close();



}


void Dialog::openSerial(void){
    if(!status)
    {
        int index = serialPortComboBox->currentIndex();
        status= true;
        serial->setPortName(QSPInfo[index].portName());
        serial->open(QIODevice::ReadWrite);
        serial->setBaudRate(QSerialPort::Baud9600); // to set the wished Baudrate
        serial->setDataBits(QSerialPort::Data8);//to set the word length
        serial->setParity(QSerialPort::NoParity);
        serial->setStopBits(QSerialPort::OneStop);
        serial->setFlowControl(QSerialPort::NoFlowControl);
        //connect(serial,SIGNAL(readyRead()), this,SLOT(serialReceived()));
        //openButton->setText("Close");
    }
    else
    {
        status = false;
        serial->close();
        //openButton->setText("Open");
    }

}


void Dialog::serialReceived( )
{
    QString ba;
    ba=serial->readAll();
    buso +=ba;
    trafficLabel->setText(buso);
}


void Dialog::updatePorts()
{
    serialPortComboBox->clear();
    int i= 0;

        foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
        {
            int x = QString::compare(info.manufacturer(), "Texas Instruments", Qt::CaseInsensitive);
            int y = QString::compare(info.manufacturer(), "TI", Qt::CaseInsensitive);
            if((x&y) == 0)
            {
                serialPortComboBox->addItem(info.description()+" - "+info.portName());
                QSPInfo[i] = info;
                i++;
            }
        }
}
